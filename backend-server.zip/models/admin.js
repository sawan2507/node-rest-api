// admin.js
const db = require("../config/db");
const bcrypt = require("bcryptjs");

const admin = {
  async create(res) {
    
    // Check if email already exists
    const existingEmail = await this.findByEmail(res.email);
    if (existingEmail) {
      return { status: false, message: "Email already in use.", id: 0 };
    }

    // Check if mobile already exists
    const existingMobile = await this.findByMobile(res.mobile);
    if (existingMobile) {
      return { status: false, message: "Mobile number already in use.", id: 0 };
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(res.password, 10);

    // Insert new user into the database
    const [result] = await db.execute(
      "INSERT INTO `admin` (`name`, `email`, `mobile`, `password`) VALUES (?, ?, ?, ?)",
      [res.name, res.email, res.mobile, hashedPassword]
    );
    console.log("User registered successfully....");
    return {
      status: false,
      message: "User registered successfully.",
      id: result.insertId,
    };
  },

  async findByUsername(username) {
    // const connection = await db();
    const [rows] = await db.execute(
      "SELECT * FROM `admins` WHERE `username` = ?",
      [username]
    );
    return rows[0];
  },

  async findByEmail(email) {
    // const connection = await db();
    console.log("Looking for email........");
    const [rows] = await db.execute(
      "SELECT * FROM `admins` WHERE `email` = ?",
      [email]
    );

    return rows[0];
  },

  async findByMobile(mobile) {
    // const connection = await db();
    console.log("Looking for mobile........");
    const [rows] = await db.execute(
      "SELECT * FROM `admins` WHERE `mobile` = ?",
      [mobile]
    );
    return rows[0];
  },

  async findById(id) {
    // const connection = await db();
    console.log("Searching for user........");

    const [rows] = await db.execute(
      "SELECT * FROM `admins` WHERE `id` = ?",
      [id]
    );
    return rows[0];
  },
  async findByResId(id) {
    // const connection = await db();
    console.log("Searching for user........");

    const [rows] = await db.execute(
      "SELECT * FROM `admins` WHERE `restaurant_id` = ?",
      [id]
    );
    return rows[0];
  },

  async updateProfile(params, id) {
    // const connection = await db();
    console.log("Updating user profile........");
    const [rows] = await db.execute(
      "UPDATE `admins` set `username` = ?, `email` = ?, `mobile` = ? WHERE `id` = ?",
      [params.username, params.email, params.mobile, id]
    );
    return rows[0];
  },
  async updateFcmToken(id, fcm_id) {
    // const connection = await db();
    console.log("Updating user profile........");
    const [rows] = await db.execute(
      "UPDATE `admins` set `desktop_token` = ? WHERE `id` = ?",
      [fcm_id, id]
    );
    return rows[0];
  },

  async updatePassword(password, id) {
    // Hash the password

    const hashedPassword = await bcrypt.hash(password, 10);
    // const connection = await db();
    const [rows] = await db.execute(
      "UPDATE `admins` set `password` = ? WHERE `id` = ?",
      [hashedPassword, id]
    );
    return rows[0];
  },

  async statistics(restaurant_id = 0) {
    if(restaurant_id > 0) {
      const products = await db.execute("SELECT COUNT(*) as total FROM `products` WHERE restaurant_id = ?", [restaurant_id]);
      const orders = await db.execute("SELECT COUNT(*) as total FROM `orders` WHERE restaurant_id = ?", [restaurant_id]);
      const earnings = await db.execute("SELECT SUM(orders.total) as total FROM `orders` WHERE restaurant_id = ?", [restaurant_id]);
      const categories = await db.execute("SELECT COUNT(*) as total FROM `categories` WHERE restaurant_id = ?", [restaurant_id]);
  
      return {
        restaurants:0,
        products:products[0][0]['total']??0,
        orders:orders[0][0]['total']??0,
        earnings:earnings[0][0]['total']??0,
        categories:categories[0][0]['total']??0
      }
    }
    const restaurants = await db.execute("SELECT COUNT(*) as total FROM `restaurants`");
    const products = await db.execute("SELECT COUNT(*) as total FROM `products`");
    const orders = await db.execute("SELECT COUNT(*) as total FROM `orders`");
    const earnings = await db.execute("SELECT SUM(orders.total) as total FROM `orders`");
    const categories = await db.execute("SELECT COUNT(*) as total FROM `categories`");

    return {
      restaurants:restaurants[0][0]['total']??0,
      products:products[0][0]['total']??0,
      orders:orders[0][0]['total']??0,
      earnings:earnings[0][0]['total']??0,
      categories:categories[0][0]['total']??0
    }

  },

  async report(restaurant_id = 0, type="monthly", start_date = "", end_date = "") {
    if(restaurant_id > 0) {
      const monthly = await db.execute("SELECT DATE_FORMAT(created_at, '%d') as date, COUNT(*) FROM orders WHERE restaurant_id = ? GROUP BY DATE_FORMAT(created_at, '%d')", [restaurant_id]);
      const yearly = await db.execute("SELECT DATE_FORMAT(created_at, '%Y') as date, COUNT(*) FROM orders WHERE restaurant_id = ? GROUP BY DATE_FORMAT(created_at, '%Y')", [restaurant_id]);
      
    }
  }

};

module.exports = admin;
